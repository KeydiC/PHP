<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>Document</title>
</head>
<body>
    <div class="cont">
        <h1 align="center">Registros academicos</h1>
        <a href="CrearBaseDeDatos.php"><button>Crear Base de datos</button></a>
        <a href="registro.php"><button>Registrar datos</button></a>
        <a href="consulta_datos.php"><button>Consultar datos</button></a>
        <a href="consulta_elimina.php"><button>Borrar consulta</button></a>
    </div>
</body>
</html>